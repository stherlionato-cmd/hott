# Checkout PIX — GitHub + Cloudflare

## Estrutura

- `site/` = site estático para Cloudflare Pages.
- `worker/` = backend Cloudflare Worker que protege a chave secreta e conversa com a Laranjinha.

## 1. Publicar o site

Crie um repositório no GitHub e envie o conteúdo da pasta `site/`.

No Cloudflare Pages:
- conecte o repositório;
- Build command: deixe vazio;
- Output directory: `/` (ou a pasta publicada);
- publique.

Depois copie a URL final do Pages.

## 2. Publicar o Worker

Instale o Wrangler e, dentro de `worker/`, execute:

```bash
npx wrangler login
npx wrangler deploy
```

Configure a chave secreta:

```bash
npx wrangler secret put LARANJINHA_SECRET_KEY
```

Cole a sua `sk_live_...` quando o Wrangler solicitar.

## 3. Configurar o domínio do site

Abra `worker/wrangler.toml` e troque:

```toml
ALLOWED_ORIGIN = "https://SEU-SITE.pages.dev"
```

pela URL real do seu Cloudflare Pages.

Depois faça novo deploy do Worker.

## 4. Configurar o endereço do Worker

Abra `site/checkout.js` e troque:

```js
const API_BASE = "https://SEU-WORKER.seu-subdominio.workers.dev";
```

pela URL real do Worker.

Depois envie novamente `checkout.js` para o GitHub.

## 5. Webhook

Esta versão usa consulta autenticada (`GET /charges/:id`) a cada 3 segundos para atualizar a página.

Isso já evita depender de comprovante enviado pelo cliente.

Para uma versão de produção mais completa, pode-se adicionar:
- D1 para guardar pedidos;
- webhook `sale.paid`;
- painel administrativo;
- entrega protegida via R2/signed URLs;
- logs e idempotência.

## Segurança

Nunca coloque `sk_live_...` em:
- HTML;
- CSS;
- JavaScript do navegador;
- GitHub;
- variáveis públicas do Pages.

A chave deve ficar somente como Secret do Cloudflare Worker.
